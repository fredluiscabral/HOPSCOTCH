#!/usr/bin/env bash
set -euo pipefail

die(){ echo "ERROR: $*" >&2; exit 1; }

# ---------- Config padrão do problema (pode sobrescrever via env) ----------
: "${N_PROB:=8192}"
: "${ALPHA:=0.1}"
: "${T_STEPS:=100}"

# Rodadas (tempo): 6 com descarte da 1a, como no texto
: "${N_RUNS:=6}"
: "${WARMUP_DISCARD:=1}"

# ---------- Utilitários ----------
tsv_get() {
  local line="$1" col="$2"
  awk -v c="$col" 'BEGIN{FS="\t"} {print $c}' <<<"$line"
}

ensure_dir(){ mkdir -p "$1"; }

# ---------- Placement ----------
# placement strings aceitas:
#   - intra0          : restringe a NUMA node 0 (R=1, t<=96)
#   - inter_socket    : distribui ao longo dos 2 sockets (padrão)
#   - intra_socket0   : "intra-socket" (blocos contíguos por task; típico p/ 2 ranks por socket em R=4)
#   - one_rank_per_socket | 1r/s : 1 rank por socket (R=2), threads locais
#   - inter           : alias p/ inter_socket
apply_placement_prefix() {
  local placement="$1" R="$2" t="$3"
  case "$placement" in
    intra0)
      echo "numactl --cpunodebind=0 --membind=0"
      ;;
    intra_socket0|inter|inter_socket|one_rank_per_socket|1r/s)
      echo ""
      ;;
    *)
      die "placement desconhecido: $placement"
      ;;
  esac
}

srun_flags_for_placement() {
  local placement="$1"
  case "$placement" in
    intra_socket0)
      # blocos contíguos por tarefa (tende a colocar 2 tarefas por socket em R=4)
      echo "--cpu-bind=cores --distribution=block:block"
      ;;
    inter|inter_socket)
      # interleaving tende a misturar sockets
      echo "--cpu-bind=cores --distribution=cyclic:block"
      ;;
    one_rank_per_socket|1r/s|intra0)
      echo "--cpu-bind=cores --distribution=block:block"
      ;;
    *)
      die "placement desconhecido: $placement"
      ;;
  esac
}

# ---------- Execução (tempo) ----------
run_walltime_once() {
  local exe="$1" tile="$2" placement="$3" R="$4" t="$5" outlog="$6"

  local prefix
  prefix="$(apply_placement_prefix "$placement" "$R" "$t")"
  local srun_flags
  srun_flags="$(srun_flags_for_placement "$placement")"

  export OMP_NUM_THREADS="$t"
  export OMP_PROC_BIND=true
  export OMP_PLACES=cores

  local param_file="param_tile${tile}.txt"
  [[ -f "$param_file" ]] || die "não achei $param_file no diretório $(pwd)"

  if [[ "$R" -eq 1 ]]; then
    /usr/bin/time -f "%e" -o "$outlog" \
      bash -lc "$prefix ./$(basename "$exe") $param_file" \
      >/dev/null 2>&1
  else
    /usr/bin/time -f "%e" -o "$outlog" \
      srun -n "$R" -c "$t" $srun_flags \
        bash -lc "$prefix ./$(basename "$exe") $param_file" \
        >/dev/null 2>&1
  fi
}

walltime_stats() {
  local exe="$1" tile="$2" placement="$3" R="$4" t="$5" run_dir="$6"
  ensure_dir "$run_dir"

  local times=()
  for rep in $(seq 1 "$N_RUNS"); do
    local tfile="$run_dir/wall_rep_${rep}.txt"
    run_walltime_once "$exe" "$tile" "$placement" "$R" "$t" "$tfile"
    times+=( "$(cat "$tfile" | tr -d '\n')" )
  done

  # descarta warmup (primeira)
  local kept=( "${times[@]:$WARMUP_DISCARD}" )

  python3 - <<'PY' "${kept[@]}"
import sys, statistics as st
vals=[float(x) for x in sys.argv[1:]]
mean=sum(vals)/len(vals)
sd=st.pstdev(vals) if len(vals)>1 else 0.0
print(f"{mean:.6f}\t{sd:.6f}")
PY
}

# ---------- uProf CLI (Exp5/6/7) ----------
: "${UPROF_BIN:=AMDuProfCLI}"

run_uprof_cli_rank0_once() {
  # Gera relatório CSV do uProf (rep_1) — coleta no rank 0 quando MPI
  local cfgs="$1" exe="$2" tile="$3" placement="$4" R="$5" t="$6" out_dir="$7"
  ensure_dir "$out_dir"

  local srun_flags
  srun_flags="$(srun_flags_for_placement "$placement")"

  export OMP_NUM_THREADS="$t"
  export OMP_PROC_BIND=true
  export OMP_PLACES=cores

  local param_file="param_tile${tile}.txt"
  [[ -f "$param_file" ]] || die "não achei $param_file no diretório $(pwd)"

  rm -f "$out_dir"/uprof_report_rep_1.csv "$out_dir"/uprof*.csv 2>/dev/null || true

  if [[ "$R" -eq 1 ]]; then
    (cd "$out_dir" && "$UPROF_BIN" collect --config "$cfgs" --output-dir . -- \
      bash -lc "$(apply_placement_prefix "$placement" "$R" "$t") ./$(basename "$exe") $param_file" \
      >/dev/null 2>&1)
  else
    (cd "$out_dir" && "$UPROF_BIN" collect --config "$cfgs" --mpi-rank 0 --output-dir . -- \
      srun -n "$R" -c "$t" $srun_flags \
        bash -lc "$(apply_placement_prefix "$placement" "$R" "$t") ./$(basename "$exe") $param_file" \
        >/dev/null 2>&1)
  fi
}

# ---------- uProf Pcm (Exp8) ----------
: "${UPROF_PCM_BIN:=AMDuProfPcm}"

run_uprof_pcm_once() {
  local metrics="$1" exe="$2" tile="$3" placement="$4" R="$5" t="$6" out_csv="$7"
  ensure_dir "$(dirname "$out_csv")"

  local srun_flags
  srun_flags="$(srun_flags_for_placement "$placement")"

  export OMP_NUM_THREADS="$t"
  export OMP_PROC_BIND=true
  export OMP_PLACES=cores

  local param_file="param_tile${tile}.txt"
  [[ -f "$param_file" ]] || die "não achei $param_file no diretório $(pwd)"

  if [[ "$R" -eq 1 ]]; then
    "$UPROF_PCM_BIN" profile -m "$metrics" -C -A system -o "$out_csv" -- \
      bash -lc "$(apply_placement_prefix "$placement" "$R" "$t") ./$(basename "$exe") $param_file" \
      >/dev/null 2>&1
  else
    "$UPROF_PCM_BIN" profile -m "$metrics" -C -A system -o "$out_csv" -- \
      srun -n "$R" -c "$t" $srun_flags \
        bash -lc "$(apply_placement_prefix "$placement" "$R" "$t") ./$(basename "$exe") $param_file" \
        >/dev/null 2>&1
  fi
}
