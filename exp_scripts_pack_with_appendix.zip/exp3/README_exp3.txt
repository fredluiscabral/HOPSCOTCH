exp3: scripts/matrizes gerados a partir do capítulo experesultados_revisado(3).tex.
