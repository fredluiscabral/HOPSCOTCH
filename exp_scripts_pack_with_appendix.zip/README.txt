Pacote de scripts (Exp1–Exp8) — SDumont II (lncc-cpu_amd)
========================================================

Binários (mesmos em todos os experimentos):
  - hopscotch2d_hib_naive
  - hopscotch2d_hib_busywait_nobarrier
  - hopscotch2d_hib_sem_nobarrier

Este pacote contém (por experimento):
  - expX_matrix.tsv   : matriz de execução (uma linha = uma configuração)
  - submit_expX.sbatch: job-array SLURM para rodar a matriz
  - scripts/common.sh : utilitários compartilhados

Observação (Exp8):
  No capítulo enviado, o Exp8 foi marcado como "não realizado ainda por falta de permissão no SD-II".
  O script do Exp8 (AMDuProfPcm) está aqui, mas irá falhar enquanto:
    /proc/sys/kernel/perf_event_paranoid > 0 e/ou o uProf não tiver capabilities/root.

Uso típico:
  cd expX
  sbatch --array=2-$(wc -l < expX_matrix.tsv) submit_expX.sbatch

Saídas:
  results/raw/  -> logs e dumps por configuração
  results/      -> CSV consolidado (append-safe)
