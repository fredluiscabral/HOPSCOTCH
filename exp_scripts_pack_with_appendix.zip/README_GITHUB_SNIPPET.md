## Reprodutibilidade (Exp1–Exp8)

Este repositório contém `scripts/` e `exp1/ ... exp8/` com:

- `expX_matrix.tsv`: matriz tabulada (uma linha por configuração)
- `submit_expX.sbatch`: SLURM job-array para executar a matriz
- `scripts/common.sh`: utilitários (tempo com 6 rodadas e descarte da 1ª, uProf CLI e uProf Pcm)

Execução:
```bash
cd expX
make -j
sbatch --array=2-$(wc -l < expX_matrix.tsv) submit_expX.sbatch
```

Saídas:
- `results/raw/<ID>/` (artefatos por ponto)
- `results/*.csv` (CSV consolidado)
