#!/usr/bin/env bash
# Wrapper por compatibilidade: chama o pós-processamento genérico.
set -euo pipefail
python3 "$(dirname "$0")/postprocess_times_stdlib.py" --prefix exp1 "$@"
