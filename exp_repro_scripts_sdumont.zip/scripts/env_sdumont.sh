#!/usr/bin/env bash
# Ambiente recomendado para SDumont II (LNCC)
set -euo pipefail

# Carregue os módulos usados na COMPILAÇÃO e na EXECUÇÃO para evitar inconsistência MPI/PMIx.
# Ajuste versões se necessário no seu ambiente.
module load amd-compilers/5.0.0
module load openmpi/amd/5.0

# uProf (Experimentos 5-8) — carregue apenas quando necessário:
if [[ "${USE_UPROF:-0}" == "1" ]]; then
  module load amd-uprof/5.1
fi
