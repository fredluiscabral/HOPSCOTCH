#!/usr/bin/env bash
# Regras de afinidade/NUMA usadas pelos scripts de experimentos.
set -euo pipefail

die(){ echo "ERROR: $*" >&2; exit 1; }

apply_placement_prefix() {
  local placement="$1" R="$2" t="$3"
  case "$placement" in
    intra0)
      echo "numactl --cpunodebind=0 --membind=0"
      ;;
    inter|inter_socket|one_rank_per_socket|1r/s|intra_socket0)
      echo ""
      ;;
    *)
      die "placement desconhecido: $placement"
      ;;
  esac
}

srun_flags_for_placement() {
  local placement="$1"
  case "$placement" in
    intra_socket0)
      echo "--cpu-bind=cores --distribution=block:block"
      ;;
    inter|inter_socket)
      echo "--cpu-bind=cores --distribution=cyclic:block"
      ;;
    one_rank_per_socket|1r/s|intra0)
      echo "--cpu-bind=cores --distribution=block:block"
      ;;
    *)
      die "placement desconhecido: $placement"
      ;;
  esac
}
