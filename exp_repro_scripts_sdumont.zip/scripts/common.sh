#!/usr/bin/env bash
set -euo pipefail

die(){ echo "ERROR: $*" >&2; exit 1; }

# ---------- Config padrão do problema (pode sobrescrever via env) ----------
: "${N_RUNS:=6}"
: "${WARMUP_DISCARD:=1}"

# ---------- Utilitários ----------
tsv_get() {
  local line="$1" col="$2"
  awk -v c="$col" 'BEGIN{FS="\t"} {print $c}' <<<"$line"
}

ensure_dir(){ mkdir -p "$1"; }

# Carrega regras de placement
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=/dev/null
source "${SCRIPT_DIR}/placement.sh"

# ---------- Temporização robusta (sem /usr/bin/time) ----------
now_ns() { date +%s%N; }

ns_to_s() {
  python3 - <<'PY' "$1"
import sys
ns=int(sys.argv[1])
print(f"{ns/1e9:.6f}")
PY
}

elapsed_s_between() {
  python3 - <<'PY' "$1" "$2"
import sys
a=int(sys.argv[1]); b=int(sys.argv[2])
print(f"{(b-a)/1e9:.6f}")
PY
}

# ---------- Execução (tempo) ----------
run_walltime_once() {
  local exe="$1" tile="$2" placement="$3" R="$4" t="$5"
  local out_time="$6" out_app_out="$7" out_app_err="$8"

  local prefix srun_flags param_file
  prefix="$(apply_placement_prefix "$placement" "$R" "$t")"
  srun_flags="$(srun_flags_for_placement "$placement")"
  param_file="param_tile${tile}.txt"
  [[ -f "$param_file" ]] || die "não achei $param_file em $(pwd)"

  export OMP_NUM_THREADS="$t"
  export OMP_PROC_BIND=true
  export OMP_PLACES=cores

  # Monta comando sem 'bash -l' (evita poluir LD_LIBRARY_PATH via shell de login)
  local start_ns end_ns rc=0

  start_ns="$(now_ns)"
  if [[ "$R" -eq 1 ]]; then
    # Usar srun mesmo em R=1 ajuda a respeitar cgroups/cpu-bind da alocação
    srun -n 1 -c "$t" $srun_flags \
      ${prefix:+$prefix }"./$(basename "$exe")" "$param_file" \
      >"$out_app_out" 2>"$out_app_err" || rc=$?
  else
    srun -n "$R" -c "$t" $srun_flags \
      ${prefix:+$prefix }"./$(basename "$exe")" "$param_file" \
      >"$out_app_out" 2>"$out_app_err" || rc=$?
  fi
  end_ns="$(now_ns)"

  # Mesmo em erro, grava tempo (útil para diagnóstico), mas sinaliza via return code.
  elapsed_s_between "$start_ns" "$end_ns" > "$out_time"
  return "$rc"
}

walltime_stats() {
  local exe="$1" tile="$2" placement="$3" R="$4" t="$5" run_dir="$6"
  ensure_dir "$run_dir"

  local times=()
  for rep in $(seq 1 "$N_RUNS"); do
    local tfile="$run_dir/wall_rep_${rep}.txt"
    local ofile="$run_dir/wall_rep_${rep}.app.out"
    local efile="$run_dir/wall_rep_${rep}.app.err"

    if ! run_walltime_once "$exe" "$tile" "$placement" "$R" "$t" "$tfile" "$ofile" "$efile"; then
      die "falha ao executar benchmark: ID_dir=$run_dir rep=$rep exe=$exe tile=$tile placement=$placement R=$R t=$t"
    fi

    local v
    v="$(tr -d '\n' < "$tfile" || true)"
    [[ -n "${v:-}" ]] || die "tempo vazio em $tfile"
    times+=( "$v" )
  done

  # descarta warmup (primeira)
  local kept=( "${times[@]:$WARMUP_DISCARD}" )

  python3 - <<'PY' "${kept[@]}"
import sys, statistics as st
vals=[float(x) for x in sys.argv[1:]]
mean=sum(vals)/len(vals)
sd=st.pstdev(vals) if len(vals)>1 else 0.0
print(f"{mean:.6f}\t{sd:.6f}")
PY
}
