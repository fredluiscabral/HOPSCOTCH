#!/usr/bin/env python3
import argparse, csv
from pathlib import Path
from collections import Counter, defaultdict

REQ_COLS = ["ID","variant","tile","R","t","placement","mean_s","sd_s"]

def die(msg):
    raise SystemExit(f"ERROR: {msg}")

def read_tsv(path: Path):
    rows = []
    with path.open("r", encoding="utf-8", newline="") as f:
        r = csv.DictReader(f, delimiter="\t")
        if r.fieldnames is None:
            die(f"{path} sem header")
        missing = [c for c in REQ_COLS if c not in r.fieldnames]
        if missing:
            die(f"colunas faltando em {path}: {missing}")
        for row in r:
            row["tile"] = int(row["tile"])
            row["R"] = int(row["R"])
            row["t"] = int(row["t"])
            row["mean_s"] = float(row["mean_s"])
            row["sd_s"] = float(row["sd_s"])
            rows.append(row)
    return rows

def write_tsv(path: Path, rows, fieldnames):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames, delimiter="\t")
        w.writeheader()
        for row in rows:
            w.writerow({k: row.get(k, "") for k in fieldnames})

def mode_of(rows, key):
    c = Counter(r[key] for r in rows)
    return c.most_common(1)[0][0]

def compute_metrics(rows):
    buckets = defaultdict(list)
    for r in rows:
        gkey = (r["variant"], r["tile"], r["placement"], r["R"])
        cores = r["R"] * r["t"]
        buckets[gkey].append((cores, r["mean_s"]))
    base = {}
    for gkey, items in buckets.items():
        items.sort(key=lambda x: (x[0], x[1]))
        base_cores, base_mean = items[0]
        base[gkey] = (base_mean, base_cores)

    out = []
    for r in rows:
        gkey = (r["variant"], r["tile"], r["placement"], r["R"])
        base_mean, base_cores = base[gkey]
        cores = r["R"] * r["t"]
        mean = r["mean_s"]
        sd = r["sd_s"]
        speedup = (base_mean / mean) if mean > 0 else float("nan")
        efficiency = speedup / (cores / base_cores) if cores > 0 else float("nan")
        cv = (sd / mean) if mean > 0 else float("nan")
        rr = dict(r)
        rr["cores"] = cores
        rr["base_mean_s"] = base_mean
        rr["base_cores"] = base_cores
        rr["speedup"] = speedup
        rr["efficiency"] = efficiency
        rr["cv"] = cv
        out.append(rr)
    return out

def pivot(rows, index_keys, col_key, val_key):
    cols = sorted({r[col_key] for r in rows})
    idx = sorted({tuple(r[k] for k in index_keys) for r in rows})
    m = {(tuple(r[k] for k in index_keys), r[col_key]): r[val_key] for r in rows}
    out_rows = []
    for ik in idx:
        d = {k: v for k, v in zip(index_keys, ik)}
        for c in cols:
            d[str(c)] = m.get((ik, c), "")
        out_rows.append(d)
    headers = list(index_keys) + [str(c) for c in cols]
    return headers, out_rows

def write_dat_files(outdir: Path, metrics_rows, tile0, placement0):
    sub = [r for r in metrics_rows if r["tile"] == tile0 and r["placement"] == placement0]
    groups = defaultdict(list)
    for r in sub:
        groups[(r["variant"], r["R"])].append(r)
    for (variant, R), g in groups.items():
        g.sort(key=lambda x: x["cores"])
        dat = outdir / f"{variant}_R{R}.dat"
        with dat.open("w", encoding="utf-8") as f:
            f.write("#cores mean_s speedup efficiency\n")
            for r in g:
                f.write(f"{r['cores']} {r['mean_s']:.6f} {r['speedup']:.6f} {r['efficiency']:.6f}\n")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--infile", required=True, help="results/expX_times.csv (TSV)")
    ap.add_argument("--outdir", required=True, help="results/processed/expX")
    ap.add_argument("--prefix", default="expX", help="prefixo dos arquivos gerados (padrão: expX)")
    args = ap.parse_args()

    infile = Path(args.infile)
    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)

    rows = read_tsv(infile)
    ids = [r["ID"] for r in rows]
    if len(ids) != len(set(ids)):
        die("IDs duplicados no CSV")

    rows_sorted = sorted(rows, key=lambda r: (r["variant"], r["tile"], r["placement"], r["R"], r["t"], r["ID"]))
    metrics = compute_metrics(rows_sorted)
    metrics_sorted = sorted(metrics, key=lambda r: (r["variant"], r["tile"], r["placement"], r["R"], r["t"], r["ID"]))

    tile0 = mode_of(rows_sorted, "tile")
    placement0 = mode_of(rows_sorted, "placement")

    write_tsv(outdir / f"{args.prefix}_clean.tsv", rows_sorted, REQ_COLS)
    mcols = REQ_COLS + ["cores","base_mean_s","base_cores","speedup","efficiency","cv"]
    write_tsv(outdir / f"{args.prefix}_metrics.tsv", metrics_sorted, mcols)

    h1, p1 = pivot(rows_sorted, ["variant","tile","placement","R"], "t", "mean_s")
    write_tsv(outdir / f"{args.prefix}_pivot_time.tsv", p1, h1)

    h2, p2 = pivot(metrics_sorted, ["variant","tile","placement","R"], "t", "speedup")
    write_tsv(outdir / f"{args.prefix}_pivot_speedup.tsv", p2, h2)

    write_tsv(outdir / f"{args.prefix}_top20_cv.tsv",
              sorted(metrics_sorted, key=lambda r: float(r["cv"]) if r["cv"] == r["cv"] else -1.0, reverse=True)[:20],
              mcols)

    write_dat_files(outdir, metrics_sorted, tile0, placement0)
    print(f"[OK] {args.prefix}: gerado em {outdir} (tile={tile0}, placement={placement0})")

if __name__ == "__main__":
    main()
