# exp_repro_scripts_sdumont.zip

Este pacote contém scripts mínimos para reproduzir as campanhas descritas no apêndice de reprodutibilidade.

Conteúdo:
- scripts/env_sdumont.sh: carrega módulos recomendados (MPI/compilador; opcional uProf via USE_UPROF=1)
- scripts/placement.sh: regras de placement (cpu-bind/NUMA) usadas pelos experimentos
- scripts/common.sh: utilitários (parsing TSV, walltime_stats sem /usr/bin/time)
- scripts/postprocess_times_stdlib.py: pós-processamento genérico (sem pandas) para CSVs expX_times.csv
- scripts/postprocess_exp1_stdlib.sh: wrapper para exp1 (compat)
- exp1/submit_exp1.sbatch: modelo robusto de submissão (suporta LINES_PER_TASK e lock no CSV)

Uso básico (exp1):
  cd exp1
  sbatch --array=2-$(wc -l < exp1_matrix.tsv) submit_exp1.sbatch

SDumont QoS (modo agregado):
  cd exp1
  N=$(( $(wc -l < exp1_matrix.tsv) - 1 ))
  L=12
  A=$(( (N + L - 1) / L ))
  sbatch --export=ALL,LINES_PER_TASK=$L --array=1-$A%4 submit_exp1.sbatch

Pós-processamento:
  cd exp1
  mkdir -p ../results/processed/exp1
  python3 ../scripts/postprocess_times_stdlib.py --prefix exp1 \
    --infile results/exp1_times.csv --outdir ../results/processed/exp1
